<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
	}
	
	public function index(){
		
		$login = $this->input->post('login'); 
		$password = $this->input->post('password'); 
		$data = null;
	
		if ($login == "admin" && $password == "admin") {
			$this->session->set_userdata('user_name', "Administrateur");
			$this->session->set_userdata('user_id', 0);
			redirect('listapplications/index'); 
		}else {
			if( $login == "" && $password == "" ) {
				$this->load->view('welcome_message',$data);
			} else {
				$data['message'] = 'Login ['.$login.'] ou mot de passe incorrect...';
				$this->load->view('welcome_message',$data);
			}
		}
	}
	
	/**
	 * Deconnexion
	 */
	function logout(){
		$this->session->unset_userdata('user_name');
		$this->session->unset_userdata('user_id');
		redirect('welcome/index'); 
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */