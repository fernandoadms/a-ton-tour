<?php

class Welcome extends Controller {

	function Welcome() {
		parent::Controller();
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}
	
	/**
	 * Affichage de la page de connexion
	 */
	function index() {
		$this->load->view('welcome_message');
	}
	
}

?>