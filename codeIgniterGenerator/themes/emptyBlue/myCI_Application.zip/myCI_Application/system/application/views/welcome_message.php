<?php
/** 
 * You have to build the login page 
 * 
 */

?>

<html>
<head>
<title>Welcome</title>

</head>
<body>
<h1>Welcome</h1>

<p>L'application est vide.</p>


</body>
</html>