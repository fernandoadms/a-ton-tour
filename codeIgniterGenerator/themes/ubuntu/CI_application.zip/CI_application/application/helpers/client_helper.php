<?php

/*
 * Created by generator
 *
 */

/**
 * Recupere la liste des enregistrements
 * @param object $db database object
 * @return array of data
 */
if (!function_exists('getAllClientsFromDB')) {
	function getAllClientsFromDB($db, $orderBy = null, $asc = null, $limit = null, $offset = null) {
		if( $orderBy != null ){
			if($asc != null) {
				$db->order_by($orderBy, $asc);
			}else {
				$db->order_by($orderBy, "asc");
			}
		}
		if( $limit == null ) {
			$query = $db->get("risclt");
		} else {
			$query = $db->limit($limit, $offset)->get("risclt");
		}
		// recuperer les enregistrements
		$records = array();
		foreach ($query->result_array() as $row) {
			$records[] = $row;
		}
		return $records;
	}
}

/**
 * Recupere le nombre d'enregistrements
 * @param object $db database object
 * @return int
 */
if (!function_exists('getCountClientsFromDB')) {
	function getCountClientsFromDB($db) {
		return $db->count_all("risclt");
	}
}

/**
 * Insere un nouvel enregistrement
 */
if (!function_exists('insertNewClient')) {
	function insertNewClient($db, $clilbnom, $clifilog, $clilbctc, $clilbmai) {
		$data=array( 'clilbnom'=>$clilbnom, 'clifilog'=>$clifilog, 'clilbctc'=>$clilbctc, 'clilbmai'=>$clilbmai);
		$db->insert('risclt',$data);
		return $db->insert_id();
	}
}


/**
 * Mise a jour d'un enregistrement
 */
if (!function_exists('updateClient')) {
	function updateClient($db, $cliidcli , $clilbnom, $clifilog, $clilbctc, $clilbmai) {
		$data = array('clilbnom'=>$clilbnom, 'clifilog'=>$clifilog, 'clilbctc'=>$clilbctc, 'clilbmai'=>$clilbmai);
		$db->where('cliidcli', $cliidcli);
		$db->update('risclt', $data);
	}
}


/**
 * Suppression d'un enregistrement
 */
if (!function_exists('deleteClient')) {
	function deleteClient($db, $cliidcli) {
		$db->delete('risclt', array('cliidcli'=>$cliidcli)); 
	}
}


/**
 * Recupere les informations d'un enregistrement
 * @param object $db database object
 * @param int id de l'enregistrement
 * @return array
 */
if (!function_exists('getClientRow')) {
	function getClientRow($db, $cliidcli) {
		$query = $db->get_where('risclt', array('cliidcli' => $cliidcli));
		if ($query->num_rows() != 1) {
			return null;
		}
		return $query->row_array();
	}
}




	/***************************************************************************
	 * USER DEFINED FUNCTIONS
	 ***************************************************************************/


?>
