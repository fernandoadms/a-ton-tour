<?php


if (!function_exists('htmlHeader')) {
	function htmlHeader($title){
		$htmlCode = metaTags() . titleTag($title) . siteCSS() ;
		return $htmlCode;
	}
}

if (!function_exists('bodyFooter')) {
	function bodyFooter(){
		$htmlCode = jquery();
		return $htmlCode;
	}
}

if (!function_exists('jquery')) {
	function jquery(){
		$htmlCode = '<script src="'.base_url().'www/bootstrap/js/jquery-1.9.1.js"></script>
		
	<script src="'.base_url().'www/js/jquery-ui/js/jquery-ui-1.10.2.custom.js"></script>
	<script src="'.base_url().'www/bootstrap/js/bootstrap.min.js"></script>

	<script src="'.base_url().'www/bootstrap/bootstrap-datepicker-master/js/bootstrap-datepicker.js"></script>
	<script src="'.base_url().'www/bootstrap/colorpicker/js/bootstrap-colorpicker.js"></script>
	';
		return $htmlCode;
	}
}


if (!function_exists('metaTags')) {
	function metaTags(){
		$htmlCode = '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
		return $htmlCode;
	}
}

if (!function_exists('titleTag')) {
	function titleTag($title){
		$htmlCode = '<title>'. $title .'</title>';
		return $htmlCode;
	}
}


if (!function_exists('siteCSS')) {
	function siteCSS(){
		$htmlCode = '<!-- JQuery-UI -->
<link href="'.base_url().'www/js/jquery-ui/css/redmond/jquery-ui-1.10.2.custom.css" rel="stylesheet">

<!-- Bootstrap -->
<link href="'.base_url().'www/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="'.base_url().'www/bootstrap/css/font-awesome.css" rel="stylesheet" media="screen">
<link href="'.base_url().'www/bootstrap/bootstrap-datepicker-master/css/datepicker.css"	rel="stylesheet" media="screen">
<link href="'.base_url().'www/bootstrap/colorpicker/css/colorpicker.css" rel="stylesheet" media="screen">

<!-- Custom site CSS -->
<link href="'.base_url().'www/bootstrap/css/override.css" rel="stylesheet" media="screen">
<link href="'.base_url().'www/css/main.css" rel="stylesheet" rel="stylesheet" media="screen">
';
		return $htmlCode;
	}
}


if (!function_exists('customCSS')) {
	function customCSS(){
		$htmlCode = '<!-- Custom CSS -->
<link rel="stylesheet" href="'.base_url().'www/css/main.css" />';
		return $htmlCode;
	}
}



?>