<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->database();
		
		$this->load->model('Utilisateur_model');
	}
	
	public function index(){
		
		$formSend = $this->input->post('formSend');

		// on est déjà connecté et on repart sur l'accueil
		if($formSend == "" && $this->session->userdata('user_id') != null){
			$this->redirectPage($this->session->userdata('user_id'), $this->session->userdata('user_name'));
		}
			  
		$login = $this->input->post('login'); 
		$password = $this->input->post('password');
		$data = null;
	
		if ($login == "admin" && $password == "lolotte") {
			$this->session->set_userdata('user_name', "Administrateur");
			$this->session->set_userdata('user_id', 0);
			redirect('listsocietes/index'); 
		}else {
			if( $login == "" && $password == "") {
				if($formSend == "true") {
					$data['message'] = 'Veuillez saisir un identifiant et un mot de passe';
				}
				$this->load->view('welcome_message',$data);
			} else {
				
				$user = Utilisateur_model::getUserLoginPassword($this->db, $login, $password);
				
				if($user != null){
					$this->session->set_userdata('user_name', $user->usrlbnom);
					$this->session->set_userdata('user_id', $user->usridusr);
					redirect('listevenements/index');
				} else {
					$data['message'] = 'Identifiant ['.$login.'] ou mot de passe incorrect...';
					$this->load->view('welcome_message',$data);
				}
				
			}
		}
	}
	
	private function redirectPage($user_id, $user_name){
		if($user_id == 0){
			redirect('listsocietes/index');
		}else{
			redirect('listevenements/index');
		}
		
	}
	
	/**
	 * Deconnexion
	 */
	function logout(){
		$this->session->unset_userdata('user_name');
		$this->session->unset_userdata('user_id');
		redirect('welcome/index'); 
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */