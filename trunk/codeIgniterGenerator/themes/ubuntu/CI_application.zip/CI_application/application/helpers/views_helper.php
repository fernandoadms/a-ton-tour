<?php

if (!function_exists('formatInfo')) {
	function formatInfo($message){
		$htmlCode = '
		<div class="alert alert-dismissable alert-info">
			<button data-dismiss="alert" class="close" type="button">×</button>
			<strong>Info : </strong>'.$message.'
		</div>';
		return $htmlCode;
	}
}

if (!function_exists('formatWarn')) {
	function formatWarn($message){
		$htmlCode = '
		<div class="alert alert-dismissable alert-warning">
			<button data-dismiss="alert" class="close" type="button">×</button>
			<strong>Attention : </strong>'.$message.'
		</div>';
		return $htmlCode;
	}
}

if (!function_exists('formatError')) {
	function formatError($message){
		$htmlCode = '
		<div class="alert alert-dismissable alert-danger">
			<button data-dismiss="alert" class="close" type="button">×</button>
			<strong>Erreur : </strong>'.$message.'
		</div>';
		return $htmlCode;
	}
}

if (!function_exists('formatConfirm')) {
	function formatConfirm($message){
		$htmlCode = '
		<div class="alert alert-dismissable alert-success">
              <button data-dismiss="alert" class="close" type="button">×</button>
              <strong>OK : </strong> '.$message.'.
		</div>';
		return $htmlCode;
	}
}



/**
 * $itemToShow --> $subItemToShow : 
 * Applications --> list || edit || detail
 * Objets --> list || edit
 */
if (!function_exists('htmlNavigation')) {
	function htmlNavigation($itemToShow, $subItemToShow, $session = null, $parameter_2 = null){
		$isAdmin = ($session->userdata('user_id') == 0);
		$htmlCode = '<div class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<div class="navbar-header"> <a class="navbar-brand" href="'.base_url().'">MyApp</a>
				</div>
				<div class="navbar-collapse collapse navbar-responsive-collapse">
					<ul class="nav navbar-nav">';
		if($isAdmin){
			$htmlCode .= '
						<li '.(($itemToShow == "client")?('class="active"'):('')).' ><a href="'.base_url().'index.php/listclients">Clients</a></li>';
		}
		$htmlCode .= '
						<li '.(($itemToShow == "groupe")?('class="active"'):('')).' ><a href="'.base_url().'index.php/listgroupes">Groupes</a></li>
						<li '.(($itemToShow == "ressource")?('class="active"'):('')).' ><a href="'.base_url().'index.php/listressources">Ressources</a></li>
						<li '.(($itemToShow == "evenement")?('class="active"'):('')).' ><a href="'.base_url().'index.php/listevenements">Evenements</a></li>
					</ul>
					<form class="navbar-form navbar-left">
                      <input type="text" placeholder="Search" class="form-control col-lg-8">
                    </form>
					<ul class="nav navbar-nav navbar-right">
						<li><a href="#">link</a></li>
  						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-user"></i> '.$session->userdata('user_name').'<b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li><a href="'.base_url().'index.php/welcome/logout">Logout</a></li>
							</ul>
						</li>          
					</ul>
				</div> <!-- .navbar-collapse -->
			</div> <!-- .container -->
		</div> <!-- .navbar -->';
		/*
		// Applications
		$htmlCode .= '<ul class="'.(($itemToShow == "Applications")?('current'):('select')).'"><li><a href="'.base_url().'index.php/listapplications"><b>Applications</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "Applications")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/listapplications">Liste</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/editapplication/index/'.$parameter_1)).'">Edition</a></li>
					<li'.(($subItemToShow == "detail")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/detailapplication/index/'.$parameter_1)).'">Détail</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';
				
		$htmlCode .= '<div class="nav-divider">&nbsp;</div>';
		
		// Objets
		$htmlCode .= '<ul class="'.(($itemToShow == "Objets")?('current'):('select')).'"><li><a href="'.base_url().'index.php/listobjets"><b>Objets</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "Objets")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/listobjets">Liste</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/edit')).'">Edition</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';
				
		// Champs
		$htmlCode .= '<ul class="'.(($itemToShow == "Champs")?('current'):('select')).'"><li><a href="'.base_url().'index.php/listchamps"><b>Champs</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "Champs")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/listchamps">Liste</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/editchamp')).'">Edition</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';
			*/
		/*
		// itemB
		$htmlCode .= '<ul class="'.(($itemToShow == "itemB")?('current'):('select')).'"><li><a href="'.base_url().'index.php/itemB"><b>itemB</b><!--[if IE 7]><!--></a><!--<![endif]-->
			<div class="select_sub '.(($itemToShow == "itemB")?('show'):('')).'">
				<ul class="sub">';
			// items
		$htmlCode .= '
					<li'.(($subItemToShow == "list")?(' class="sub_show"'):('')).'><a href="'.base_url().'index.php/list">list</a></li>
					<li'.(($subItemToShow == "edit")?(' class="sub_show"'):('')).'><a href="'.(($subItemToShow == "list")?('#'):(base_url().'index.php/edit')).'">Edition</a></li>';
		$htmlCode .= '
				</ul>
			</div>
			</li>
			</ul>';*/
		
		// end of menu
				
		
		return $htmlCode;
	}
}

/*
if (!function_exists('htmlMenu')) {
	function htmlMenu($userProfile){
		$htmlCode = '<ul id="nav" class="dropdown dropdown-horizontal">
		<li><a href="'.base_url().'index.php">Home</a></li>
		<li><a href="#" class="dir">Produits</a>
			<ul>
				<li><a href="'.base_url().'index.php/listproduits">Liste</a></li>
				<li><a href="'.base_url().'index.php/listproduits#new">Nouveau</a></li>
			</ul>
		</li>
		<li><a href="./" class="dir">Classement</a>
			<ul>
				<li class="empty">&#8250;&#8250; Catégories</li>
				<li><a href="'.base_url().'index.php/listcategories">Liste</a></li>
				<li><a href="'.base_url().'index.php/listcategories#new">Nouveau</a></li>
				<li class="empty">&#8250;&#8250; Sous-Catégories</li>
				<li><a href="'.base_url().'index.php/listsouscategories">Liste</a></li>
				<li><a href="'.base_url().'index.php/listsouscategories#new">Nouveau</a></li>
				<li class="empty">&#8250;&#8250; Rubriques</li>
				<li><a href="'.base_url().'index.php/listrubriques">Liste</a></li>
				<li><a href="'.base_url().'index.php/listrubriques#new">Nouveau</a></li>
			</ul>
		</li>
		<li><a href="./" class="dir">News</a>
			<ul>
				<li><a href="'.base_url().'index.php/listnewss">Liste</a></li>
				<li><a href="'.base_url().'index.php/listnewss#new">Nouvelle news</a></li>
			</ul>
		</li>
		<li><a href="./" class="dir">Quitter</a>
			<ul>
				<li><a href="'.base_url().'index.php/welcome/logout">Retour au site</a></li>
			</ul>
		</li>
		</ul>';
		return $htmlCode;
	}
}
*/
?>