<?php
/**
 * GLobal messages
 */

$lang['form.button.save'] = "Enregistrer";
$lang['form.button.cancel'] = "Annuler";
$lang['form.button.edit'] = "Editer";
$lang['form.button.delete'] = "Supprimer";
$lang['form.button.create'] = "Ajouter";

$lang['object.tableheader.actions'] = "Actions";

$lang['form.loginForm.username.label'] = "Identifiant";
$lang['form.loginForm.password.label'] = "Mot de passe";
$lang['form.loginForm.submitButton.label'] = "Login";


?>