<?php

if (! defined('BASEPATH')) {
	exit('No direct script access');
}

class CIU_Controller extends CI_Controller {
	
	public function index()
	{
		return;
	}
	
}

/* End of file CIU_Controller.php */
/* Location: ./application/third_party/CIUnit/core/CIU_Controller.php */