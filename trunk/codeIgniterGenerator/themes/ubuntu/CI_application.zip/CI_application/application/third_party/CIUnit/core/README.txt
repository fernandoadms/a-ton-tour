Overwriting some of the CodeIgniter base functionality.

CLI is just different.