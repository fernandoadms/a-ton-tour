
<br />
<div class="chrono">All tests completed in <?php echo $this->benchmark->elapsed_time('total_execution_time_start', 'total_execution_time_end');?> seconds</div>


</body>
</html> 