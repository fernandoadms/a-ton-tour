<?php
$this->load->helper('url');
$this->load->helper('form');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome</title>
<link rel="stylesheet" href="<?=base_url()?>www/css/main.css" type="text/css" media="screen" title="default" />
<!-- Bootstrap -->
<link href="<?=base_url()?>www/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link rel="stylesheet" href="<?=base_url()?>www/bootstrap/css/override.css">
<link rel="stylesheet" href="<?=base_url()?>www/bootstrap/css/font-awesome.css">

</head>
<body id="login-bg">
<div class="login-box">
	<div class="brand-login">
		<div class="brand-logo">My App</div>
	</div>

<div class="well">
<?php
$attributes_info = array('name' => 'LoginForm');
$fields_info = array("formSend" => "true");
echo form_open_multipart('welcome/index', $attributes_info, $fields_info );
?>
		<fieldset>
			<legend><i class="icon-signin"></i> Connexion</legend>
<?php if(isset($message) && $message != ""){ ?>
			<div class="login-error"><?= $message ?></div>
<?php } ?>
			<div class="form-group">
				<label for="username">Identifiant</label>
				<div class="div_text">
					<div class="input-group"><span class="input-group-addon"><i class="icon-user"></i></span><input type="text" class="username span2 form-control" value="" id="login" name="login"></div>
	
				</div>
			</div>
			
			<div class="form-group">
				<label for="password">Mot de passe</label>
				<div class="div_text">
					<div class="input-group"><span class="input-group-addon"><i class="icon-lock"></i></span><input type="password" class="password span2 form-control" value="************" onfocus="this.value=''" class="login-inp" name="password" id="password"></div>
				</div>
			</div>
				
			<div class="form-group">
				<div class="button_div"><input type="submit" class="btn btn-primary" value="Login" name="Submit"></div>
			</div>

			<div class="clear"></div>
		</fieldset>

<?php
echo form_close('');
?>

</div>
<!-- End: .well -->

</div> 
<!-- End: login-box -->

</body>
</html>