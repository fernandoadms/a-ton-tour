<?php

/*
 * Created by generator
 *
 */

/**
 * Recupere la liste des enregistrements
 * @param object $db database object
 * @return array of data
 */
if (!function_exists('getAllClientsFromDB')) {
	function getAllClientsFromDB($db) {
		$sql = "SELECT cliidcli, clilbnom, clilbaf1, clilbaf2, clilbcpf, clilbvif, clilbal1, clilbal2, clilbcpl, clilbvil, clilbtel, ctclbmai, ctclnres from delcli ";
		$query = $db->query($sql);

		// recuperer les enregistrements
		$records = array();
		foreach ($query->result_array() as $row) {
			$records[] = $row;
		}
		return $records;
	}
}


/**
 * Insere un nouvel enregistrement
 * @param object $db database object
 * @param string ...
 * @return number identifiant
 */
if (!function_exists('insertNewClient')) {
	function insertNewClient($db, $clilbnom, $clilbaf1, $clilbaf2, $clilbcpf, $clilbvif, $clilbal1, $clilbal2, $clilbcpl, $clilbvil, $clilbtel, $ctclbmai, $ctclnres) {
		$data=array( 'clilbnom'=>$clilbnom, 'clilbaf1'=>$clilbaf1, 'clilbaf2'=>$clilbaf2, 'clilbcpf'=>$clilbcpf, 'clilbvif'=>$clilbvif, 'clilbal1'=>$clilbal1, 'clilbal2'=>$clilbal2, 'clilbcpl'=>$clilbcpl, 'clilbvil'=>$clilbvil, 'clilbtel'=>$clilbtel, 'ctclbmai'=>$ctclbmai, 'ctclnres'=>$ctclnres );
		$db->insert('delcli',$data);
		return $db->insert_id();
	}
}

/**
 * Mise a jour d'un enregistrement
 */
if (!function_exists('updateClient')) {
	function updateClient($db, $cliidcli, $clilbnom, $clilbaf1, $clilbaf2, $clilbcpf, $clilbvif, $clilbal1, $clilbal2, $clilbcpl, $clilbvil, $clilbtel, $ctclbmai, $ctclnres) {
		$sql = "update delcli set clilbnom = ?, clilbaf1 = ?, clilbaf2 = ?, clilbcpf = ?, clilbvif = ?, clilbal1 = ?, clilbal2 = ?, clilbcpl = ?, clilbvil = ?, clilbtel = ?, ctclbmai = ?, ctclnres = ? where cliidcli = ?";
		$query = $db->query($sql, array($clilbnom, $clilbaf1, $clilbaf2, $clilbcpf, $clilbvif, $clilbal1, $clilbal2, $clilbcpl, $clilbvil, $clilbtel, $ctclbmai, $ctclnres, $cliidcli));
	}
}


/**
 * Suppression d'un enregistrement
 */
if (!function_exists('deleteClient')) {
	function deleteClient($db, $cliidcli) {
		$sql = "delete from delcli where cliidcli = ?";
		$query = $db->query($sql, array((int)$cliidcli));
	}
}


/**
 * Recupere les informations d'un enregistrement
 * @param object $db database object
 * @param int id de l'enregistrement
 * @return array
 */
if (!function_exists('getClientRow')) {
	function getClientRow($db, $cliidcli) {
		$sql = "select cliidcli, clilbnom, clilbaf1, clilbaf2, clilbcpf, clilbvif, clilbal1, clilbal2, clilbcpl, clilbvil, clilbtel, ctclbmai, ctclnres from delcli " .
		"where cliidcli = ?";
		$query = $db->query($sql, array($cliidcli));
		if ($query->num_rows() == 0) {
			return null;
		}
		return $query->row_array();
	}
}

?>
