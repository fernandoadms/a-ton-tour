<?php
/*
 * Created by generator
 *
 */

class Client_model extends Model {
	
	var $cliidcli;
	var $clilbnom;
	var $clilbaf1;
	var $clilbaf2;
	var $clilbcpf;
	var $clilbvif;
	var $clilbal1;
	var $clilbal2;
	var $clilbcpl;
	var $clilbvil;
	var $clilbtel;
	var $ctclbmai;
	var $ctclnres;
	
	/**
	 * Constructeur
	 */
	function Client_model(){
		parent::Model();
		$this->load->helper('client');
		
	}
	
	/************************************************************************
	 * Methodes de mise a jour a partir de la base de donnees
	 ************************************************************************/

	/**
	 * Cree une nouvelle instance a partir d'un enregistrement de base de donnees
	 */
	static function Client_modelFromRow($row){
		$model = new Client_model();
		$model->cliidcli = $row['cliidcli'];
		$model->clilbnom = $row['clilbnom'];
		$model->clilbaf1 = $row['clilbaf1'];
		$model->clilbaf2 = $row['clilbaf2'];
		$model->clilbcpf = $row['clilbcpf'];
		$model->clilbvif = $row['clilbvif'];
		$model->clilbal1 = $row['clilbal1'];
		$model->clilbal2 = $row['clilbal2'];
		$model->clilbcpl = $row['clilbcpl'];
		$model->clilbvil = $row['clilbvil'];
		$model->clilbtel = $row['clilbtel'];
		$model->ctclbmai = $row['ctclbmai'];
		$model->ctclnres = $row['ctclnres'];
		return $model;
	}

	/**
	 * recupere tous les enregistrements
	 * @param $db connexion a la base de donnees
	 */
	static function getAllClients($db){
		$rows = getAllClientsFromDB($db);
		$records = array();
		foreach ($rows as $row) {
			$records[] = Client_model::Client_modelFromRow($row);
		}
		return $records;
	}
	
	/**
	 * Recupere l'enregistrement a partir de son id
	 * @param $db database
	 * @param $cliidcli identifiant de l'enregistrement a recuperer
	 */
	static function getClient($db, $cliidcli){
		$row = getClientRow($db, $cliidcli);
		return Client_model::Client_modelFromRow($row);
	}
	
	/**
	 * Suppression d'un enregistrement
	 * @param $db database
	 * @param $cliidcli identifiant de l'enregistrement a supprimer
	 */
	static function delete($db, $cliidcli){
		deleteClient($db, $cliidcli);
	}

	/**
	 * Enregistre en base un nouvel enregistrement
	 * @param $db
	 */
	public function save($db){
		$this->cliidcli = insertNewClient($db, $this->clilbnom, $this->clilbaf1, $this->clilbaf2, $this->clilbcpf, $this->clilbvif, $this->clilbal1, $this->clilbal2, $this->clilbcpl, $this->clilbvil, $this->clilbtel, $this->ctclbmai, $this->ctclnres);
	}

	/**
	 * Mise a jour des donnees d'un enregistrement
	 * @param db $db
	 */
	public function update($db){
		updateClient($db, $this->cliidcli, $this->clilbnom, $this->clilbaf1, $this->clilbaf2, $this->clilbcpf, $this->clilbvif, $this->clilbal1, $this->clilbal2, $this->clilbcpl, $this->clilbvil, $this->clilbtel, $this->ctclbmai, $this->ctclnres);
	}


}

?>
