<?php
/*
 * Created by generator
 *
 */

class EditClient extends Controller {

	function EditClient(){
		parent::Controller();
		$this->load->model('Client_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}


	/**
	 * Affichage des infos
	 */
	public function index($cliidcli){
		$model = Client_model::getClient($this->db, $cliidcli);
		$data['client'] = $model;

		$this->load->view('editclient_view',$data);
	}

	/**
	 * Sauvegarde des modifications
	 */
	public function save(){
		// Mise a jour des donnees en base
		$model = new Client_model();
		$model->cliidcli = $this->input->post('cliidcli');
		$model->clilbnom = $this->input->post('nomEnseigne'); 
		$model->clilbaf1 = $this->input->post('adresseFactu1'); 
		$model->clilbaf2 = $this->input->post('adresseFactu2'); 
		$model->clilbcpf = $this->input->post('CPFactu'); 
		$model->clilbvif = $this->input->post('villeFactu'); 
		$model->clilbal1 = $this->input->post('adresseLiv1'); 
		$model->clilbal2 = $this->input->post('adresseLiv2'); 
		$model->clilbcpl = $this->input->post('CPLiv'); 
		$model->clilbvil = $this->input->post('villeLiv'); 
		$model->clilbtel = $this->input->post('telephone'); 
		$model->ctclbmai = $this->input->post('mail'); 
		$model->ctclnres = $this->input->post('responsable'); 
		$model->update($this->db);

		$this->session->set_userdata('message', formatInfo('Client mis a jour'));

		redirect('listclients/index'); 
	}
	
}
?>

