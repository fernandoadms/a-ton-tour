<?php
/*
 * Created by generator
 *
 */

$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('template');
?>

<html>
<head>
<? echo htmlHeader('Editer un Client'); ?>

</head>
<body>

<div class="container">  
	<h1><img src="<?=base_url()?>www/images/logo.jpg"/ style="vertical-align:middle;"> Specs</h1>
	<hr>
	<div class="prepend-1 colborder">

<?= htmlNavigation() ?>
	<h2><img src="<?=base_url()?>www/images/client.png"/ style="vertical-align:middle;"> Client </h2>
	<div class="span-24">

	<fieldset>
<?
$attributes_info = array('name' => 'EditForm');
$fields_info = array('cliidcli' => $client->cliidcli);
echo form_open_multipart('editclient/save', $attributes_info, $fields_info );
?>
	<table>
		<tr><td><label for="nomEnseigne">nomEnseigne</label> : </td><td><input type="text" name="nomEnseigne" id="nomEnseigne" value="<?= $client->clilbnom ?>"></td></tr>
		<tr><td><label for="adresseFactu1">adresseFactu1</label> : </td><td><input type="text" name="adresseFactu1" id="adresseFactu1" value="<?= $client->clilbaf1 ?>"></td></tr>
		<tr><td><label for="adresseFactu2">adresseFactu2</label> : </td><td><input type="text" name="adresseFactu2" id="adresseFactu2" value="<?= $client->clilbaf2 ?>"></td></tr>
		<tr><td><label for="CPFactu">CPFactu</label> : </td><td><input type="text" name="CPFactu" id="CPFactu" value="<?= $client->clilbcpf ?>"></td></tr>
		<tr><td><label for="villeFactu">villeFactu</label> : </td><td><input type="text" name="villeFactu" id="villeFactu" value="<?= $client->clilbvif ?>"></td></tr>
		<tr><td><label for="adresseLiv1">adresseLiv1</label> : </td><td><input type="text" name="adresseLiv1" id="adresseLiv1" value="<?= $client->clilbal1 ?>"></td></tr>
		<tr><td><label for="adresseLiv2">adresseLiv2</label> : </td><td><input type="text" name="adresseLiv2" id="adresseLiv2" value="<?= $client->clilbal2 ?>"></td></tr>
		<tr><td><label for="CPLiv">CPLiv</label> : </td><td><input type="text" name="CPLiv" id="CPLiv" value="<?= $client->clilbcpl ?>"></td></tr>
		<tr><td><label for="villeLiv">villeLiv</label> : </td><td><input type="text" name="villeLiv" id="villeLiv" value="<?= $client->clilbvil ?>"></td></tr>
		<tr><td><label for="telephone">telephone</label> : </td><td><input type="text" name="telephone" id="telephone" value="<?= $client->clilbtel ?>"></td></tr>
		<tr><td><label for="mail">mail</label> : </td><td><input type="text" name="mail" id="mail" value="<?= $client->ctclbmai ?>"></td></tr>
		<tr><td><label for="responsable">responsable</label> : </td><td><input type="text" name="responsable" id="responsable" value="<?= $client->ctclnres ?>"></td></tr>
		<tr>
			<td></td>
			<td>
				<button onclick="document.forms['EditForm'].sumbit()">
					<span class="ss_sprite ss_accept"> &nbsp; </span> Enregistrer
				</button>
			</td>
		</tr>
	</table>
<?
echo form_close('');
?>
	</fieldset>
	</div>
	</div>
</div>

</body>
</html>
