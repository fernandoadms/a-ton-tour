<?php
/*
 * Created by generator
 *
 */

class ListClients extends Controller {

	/**
	 * Constructeur
	 */
	function ListClients(){
		parent::Controller();
		$this->load->model('Client_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}

	/**
	 * Affichage des Client
	 */
	public function index(){
		$data['clients'] = Client_model::getAllClients($this->db);
		$this->load->view('listclients_view', $data);
	}

	/**
	 * Ajout d'un Client
	 */
	public function add(){

		// Insertion en base
		$model = new Client_model();
		$model->clilbnom = $this->input->post('nomEnseigne'); 
		$model->clilbaf1 = $this->input->post('adresseFactu1'); 
		$model->clilbaf2 = $this->input->post('adresseFactu2'); 
		$model->clilbcpf = $this->input->post('CPFactu'); 
		$model->clilbvif = $this->input->post('villeFactu'); 
		$model->clilbal1 = $this->input->post('adresseLiv1'); 
		$model->clilbal2 = $this->input->post('adresseLiv2'); 
		$model->clilbcpl = $this->input->post('CPLiv'); 
		$model->clilbvil = $this->input->post('villeLiv'); 
		$model->clilbtel = $this->input->post('telephone'); 
		$model->ctclbmai = $this->input->post('mail'); 
		$model->ctclnres = $this->input->post('responsable'); 
		$model->save($this->db);

		$this->session->set_userdata('message', formatInfo('Nouveau Client ajoute'));
		
		// Recharge la page avec les nouvelles infos
		redirect('listclients/index'); 
	}

	/**
	 * Suppression d'un Client
	 * @param $cliidcli identifiant a supprimer
	 */
	function delete($cliidcli){
		Client_model::delete($this->db, $cliidcli);

		$this->session->set_userdata('message', formatInfo('Client supprime'));

		redirect('listclients/index'); 
	}

}
?>
