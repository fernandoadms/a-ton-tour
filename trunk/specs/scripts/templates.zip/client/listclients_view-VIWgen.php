<?php
/*
 * Created by generator
 *
 */

$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('template');
?>

<html>
<head>
<? echo htmlHeader('Client'); ?>

</head>
<body>


<div class="container">  
	<h1><img src="<?=base_url()?>www/images/logo.jpg"/ style="vertical-align:middle;"> Specs</h1>
	<hr>
	<div class="prepend-1 colborder">

<?= htmlNavigation() ?>


	<div class="span-12"><h2><img src="<?=base_url()?>www/images/client.png"/ style="vertical-align:middle;"> Liste des Client</h2></div>
	<div class="span-7 last" style="float: right;"><?echo $this->session->userdata('message'); $this->session->unset_userdata('message')?></div>

	<table class="visible">
		<tr class="header">
			<th>identifiant</th>
			<th>nomEnseigne</th>
			<th>adresseFactu1</th>
			<th>adresseFactu2</th>
			<th>CPFactu</th>
			<th>villeFactu</th>
			<th>adresseLiv1</th>
			<th>adresseLiv2</th>
			<th>CPLiv</th>
			<th>villeLiv</th>
			<th>telephone</th>
			<th>mail</th>
			<th>responsable</th>
			<th>Supprimer</th>
		</tr>
	<?php
	$even = true;
	foreach($clients as $client):
	?>
		<tr <?=($even)?('class="even"'):('')?>>
			<td valign="top"><a title="Modifier ce Client" href="<?=base_url()?>index.php/editclient/index/<?=$client->cliidcli?>"><?=$client->cliidcli?></a></td>
			<td valign="top"><?=$client->clilbnom?></td> 
			<td valign="top"><?=$client->clilbaf1?></td> 
			<td valign="top"><?=$client->clilbaf2?></td> 
			<td valign="top"><?=$client->clilbcpf?></td> 
			<td valign="top"><?=$client->clilbvif?></td> 
			<td valign="top"><?=$client->clilbal1?></td> 
			<td valign="top"><?=$client->clilbal2?></td> 
			<td valign="top"><?=$client->clilbcpl?></td> 
			<td valign="top"><?=$client->clilbvil?></td> 
			<td valign="top"><?=$client->clilbtel?></td> 
			<td valign="top"><?=$client->ctclbmai?></td> 
			<td valign="top"><?=$client->ctclnres?></td> 
			<td valign="top">
				<a href="#" title="Supprimer ce Client" onclick="if(confirm('Desirez vous supprimer ce Client ?')){location.href='<?=base_url()?>index.php/listclients/delete/<?=$client->cliidcli?>'}">
				<img src="<?=base_url()?>www/images/delete_16.png"></a>
			</td>
		</tr>
		
	<?php $even = !$even;
	 endforeach;?>
</table>
<hr>
<fieldset>
	<legend><img src="<?=base_url()?>www/images/plus_16.png"> Ajouter un Client</legend>

<?
$attributes_info = array('name' => 'AddForm');
$fields_info = array();
echo form_open_multipart('listclients/add', $attributes_info, $fields_info );
?>
	<table>
		<tr><td><label for="identifiant">identifiant</label> : </td><td><input type="text" name="identifiant" id="identifiant"></td></tr>
		<tr><td><label for="nomEnseigne">nomEnseigne</label> : </td><td><input type="text" name="nomEnseigne" id="nomEnseigne"></td></tr>
		<tr><td><label for="adresseFactu1">adresseFactu1</label> : </td><td><input type="text" name="adresseFactu1" id="adresseFactu1"></td></tr>
		<tr><td><label for="adresseFactu2">adresseFactu2</label> : </td><td><input type="text" name="adresseFactu2" id="adresseFactu2"></td></tr>
		<tr><td><label for="CPFactu">CPFactu</label> : </td><td><input type="text" name="CPFactu" id="CPFactu"></td></tr>
		<tr><td><label for="villeFactu">villeFactu</label> : </td><td><input type="text" name="villeFactu" id="villeFactu"></td></tr>
		<tr><td><label for="adresseLiv1">adresseLiv1</label> : </td><td><input type="text" name="adresseLiv1" id="adresseLiv1"></td></tr>
		<tr><td><label for="adresseLiv2">adresseLiv2</label> : </td><td><input type="text" name="adresseLiv2" id="adresseLiv2"></td></tr>
		<tr><td><label for="CPLiv">CPLiv</label> : </td><td><input type="text" name="CPLiv" id="CPLiv"></td></tr>
		<tr><td><label for="villeLiv">villeLiv</label> : </td><td><input type="text" name="villeLiv" id="villeLiv"></td></tr>
		<tr><td><label for="telephone">telephone</label> : </td><td><input type="text" name="telephone" id="telephone"></td></tr>
		<tr><td><label for="mail">mail</label> : </td><td><input type="text" name="mail" id="mail"></td></tr>
		<tr><td><label for="responsable">responsable</label> : </td><td><input type="text" name="responsable" id="responsable"></td></tr>
		<tr>
			<td></td>
			<td>
				<button onclick="document.forms['AddForm'].sumbit()">
					<span class="ss_sprite ss_add"> &nbsp; </span> Ajouter
				</button>
			</td>
		</tr>
	</table>

<?
echo form_close('');
?>
</fieldset>
	</div>
</div>

</body>
</html>
