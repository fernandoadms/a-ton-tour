<?php
/*
 * Created by generator
 *
 */

class Detail_model extends Model {
	
	var $detiddet;
	var $famidfam;
	var $detlblib;
	var $detnbmou;
	var $detnbqtt;
	var $detnbmar;
	var $dvsiddvs;
	var $dettxdcl;
	
	/**
	 * Constructeur
	 */
	function Detail_model(){
		parent::Model();
		$this->load->helper('detail');
		
	}
	
	/************************************************************************
	 * Methodes de mise a jour a partir de la base de donnees
	 ************************************************************************/

	/**
	 * Cree une nouvelle instance a partir d'un enregistrement de base de donnees
	 */
	static function Detail_modelFromRow($row){
		$model = new Detail_model();
		$model->detiddet = $row['detiddet'];
		$model->famidfam = $row['famidfam'];
		$model->detlblib = $row['detlblib'];
		$model->detnbmou = $row['detnbmou'];
		$model->detnbqtt = $row['detnbqtt'];
		$model->detnbmar = $row['detnbmar'];
		$model->dvsiddvs = $row['dvsiddvs'];
		$model->dettxdcl = $row['dettxdcl'];
		return $model;
	}

	/**
	 * recupere tous les enregistrements
	 * @param $db connexion a la base de donnees
	 */
	static function getAllDetails($db){
		$rows = getAllDetailsFromDB($db);
		$records = array();
		foreach ($rows as $row) {
			$records[] = Detail_model::Detail_modelFromRow($row);
		}
		return $records;
	}
	
	/**
	 * Recupere l'enregistrement a partir de son id
	 * @param $db database
	 * @param $detiddet identifiant de l'enregistrement a recuperer
	 */
	static function getDetail($db, $detiddet){
		$row = getDetailRow($db, $detiddet);
		return Detail_model::Detail_modelFromRow($row);
	}
	
	/**
	 * Suppression d'un enregistrement
	 * @param $db database
	 * @param $detiddet identifiant de l'enregistrement a supprimer
	 */
	static function delete($db, $detiddet){
		deleteDetail($db, $detiddet);
	}

	/**
	 * Enregistre en base un nouvel enregistrement
	 * @param $db
	 */
	public function save($db){
		$this->detiddet = insertNewDetail($db, $this->famidfam, $this->detlblib, $this->detnbmou, $this->detnbqtt, $this->detnbmar, $this->dvsiddvs, $this->dettxdcl);
	}

	/**
	 * Mise a jour des donnees d'un enregistrement
	 * @param db $db
	 */
	public function update($db){
		updateDetail($db, $this->detiddet, $this->famidfam, $this->detlblib, $this->detnbmou, $this->detnbqtt, $this->detnbmar, $this->dvsiddvs, $this->dettxdcl);
	}


}

?>
