<?php
/*
 * Created by generator
 *
 */

class EditDetail extends Controller {

	function EditDetail(){
		parent::Controller();
		$this->load->model('Detail_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}


	/**
	 * Affichage des infos
	 */
	public function index($detiddet){
		$model = Detail_model::getDetail($this->db, $detiddet);
		$data['detail'] = $model;

		$this->load->view('editdetail_view',$data);
	}

	/**
	 * Sauvegarde des modifications
	 */
	public function save(){
		// Mise a jour des donnees en base
		$model = new Detail_model();
		$model->detiddet = $this->input->post('detiddet');
		$model->famidfam = $this->input->post('famille'); 
		$model->detlblib = $this->input->post('libelle'); 
		$model->detnbmou = $this->input->post('montantUnitaire'); 
		$model->detnbqtt = $this->input->post('quantite'); 
		$model->detnbmar = $this->input->post('marge'); 
		$model->dvsiddvs = $this->input->post('devis'); 
		$model->dettxdcl = $this->input->post('descriptionClient'); 
		$model->update($this->db);

		$this->session->set_userdata('message', formatInfo('Detail mis a jour'));

		redirect('listdetails/index'); 
	}
	
}
?>

