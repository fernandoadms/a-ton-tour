<?php
/*
 * Created by generator
 *
 */

$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('template');
?>

<html>
<head>
<? echo htmlHeader('Editer un Detail'); ?>

</head>
<body>

<div class="container">  
	<h1><img src="<?=base_url()?>www/images/logo.jpg"/ style="vertical-align:middle;"> Specs</h1>
	<hr>
	<div class="prepend-1 colborder">

<?= htmlNavigation() ?>
	<h2><img src="<?=base_url()?>www/images/detail.png"/ style="vertical-align:middle;"> Detail </h2>
	<div class="span-24">

	<fieldset>
<?
$attributes_info = array('name' => 'EditForm');
$fields_info = array('detiddet' => $detail->detiddet);
echo form_open_multipart('editdetail/save', $attributes_info, $fields_info );
?>
	<table>
		<tr><td><label for="famille">famille</label> : </td><td><input type="text" name="famille" id="famille" value="<?= $detail->famidfam ?>"></td></tr>
		<tr><td><label for="libelle">libelle</label> : </td><td><input type="text" name="libelle" id="libelle" value="<?= $detail->detlblib ?>"></td></tr>
		<tr><td><label for="montantUnitaire">montantUnitaire</label> : </td><td><input type="text" name="montantUnitaire" id="montantUnitaire" value="<?= $detail->detnbmou ?>"></td></tr>
		<tr><td><label for="quantite">quantite</label> : </td><td><input type="text" name="quantite" id="quantite" value="<?= $detail->detnbqtt ?>"></td></tr>
		<tr><td><label for="marge">marge</label> : </td><td><input type="text" name="marge" id="marge" value="<?= $detail->detnbmar ?>"></td></tr>
		<tr><td><label for="devis">devis</label> : </td><td><input type="text" name="devis" id="devis" value="<?= $detail->dvsiddvs ?>"></td></tr>
		<tr><td><label for="descriptionClient">descriptionClient</label> : </td><td><input type="text" name="descriptionClient" id="descriptionClient" value="<?= $detail->dettxdcl ?>"></td></tr>
		<tr>
			<td></td>
			<td>
				<button onclick="document.forms['EditForm'].sumbit()">
					<span class="ss_sprite ss_accept"> &nbsp; </span> Enregistrer
				</button>
			</td>
		</tr>
	</table>
<?
echo form_close('');
?>
	</fieldset>
	</div>
	</div>
</div>

</body>
</html>
