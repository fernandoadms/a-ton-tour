<?php
/*
 * Created by generator
 *
 */

class ListDetails extends Controller {

	/**
	 * Constructeur
	 */
	function ListDetails(){
		parent::Controller();
		$this->load->model('Detail_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}

	/**
	 * Affichage des Detail
	 */
	public function index(){
		$data['details'] = Detail_model::getAllDetails($this->db);
		$this->load->view('listdetails_view', $data);
	}

	/**
	 * Ajout d'un Detail
	 */
	public function add(){

		// Insertion en base
		$model = new Detail_model();
		$model->famidfam = $this->input->post('famille'); 
		$model->detlblib = $this->input->post('libelle'); 
		$model->detnbmou = $this->input->post('montantUnitaire'); 
		$model->detnbqtt = $this->input->post('quantite'); 
		$model->detnbmar = $this->input->post('marge'); 
		$model->dvsiddvs = $this->input->post('devis'); 
		$model->dettxdcl = $this->input->post('descriptionClient'); 
		$model->save($this->db);

		$this->session->set_userdata('message', formatInfo('Nouveau Detail ajoute'));
		
		// Recharge la page avec les nouvelles infos
		redirect('listdetails/index'); 
	}

	/**
	 * Suppression d'un Detail
	 * @param $detiddet identifiant a supprimer
	 */
	function delete($detiddet){
		Detail_model::delete($this->db, $detiddet);

		$this->session->set_userdata('message', formatInfo('Detail supprime'));

		redirect('listdetails/index'); 
	}

}
?>
