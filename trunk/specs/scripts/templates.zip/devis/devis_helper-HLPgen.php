<?php

/*
 * Created by generator
 *
 */

/**
 * Recupere la liste des enregistrements
 * @param object $db database object
 * @return array of data
 */
if (!function_exists('getAllDevissFromDB')) {
	function getAllDevissFromDB($db) {
		$sql = "SELECT dvsiddvs, dvsnbmgl, dvsdtcre, dvsidusr, dvsdtexp, cliidcli, dvslblib, dvstxdcl, dvstxdpr, dvsdtecl, dvsdtlcl, dvsdtefc, dvsdtrfc from deldvs ";
		$query = $db->query($sql);

		// recuperer les enregistrements
		$records = array();
		foreach ($query->result_array() as $row) {
			$records[] = $row;
		}
		return $records;
	}
}


/**
 * Insere un nouvel enregistrement
 * @param object $db database object
 * @param string ...
 * @return number identifiant
 */
if (!function_exists('insertNewDevis')) {
	function insertNewDevis($db, $dvsnbmgl, $dvsdtcre, $dvsidusr, $dvsdtexp, $cliidcli, $dvslblib, $dvstxdcl, $dvstxdpr, $dvsdtecl, $dvsdtlcl, $dvsdtefc, $dvsdtrfc) {
		$data=array( 'dvsnbmgl'=>$dvsnbmgl, 'dvsdtcre'=>$dvsdtcre, 'dvsidusr'=>$dvsidusr, 'dvsdtexp'=>$dvsdtexp, 'cliidcli'=>$cliidcli, 'dvslblib'=>$dvslblib, 'dvstxdcl'=>$dvstxdcl, 'dvstxdpr'=>$dvstxdpr, 'dvsdtecl'=>$dvsdtecl, 'dvsdtlcl'=>$dvsdtlcl, 'dvsdtefc'=>$dvsdtefc, 'dvsdtrfc'=>$dvsdtrfc );
		$db->insert('deldvs',$data);
		return $db->insert_id();
	}
}

/**
 * Mise a jour d'un enregistrement
 */
if (!function_exists('updateDevis')) {
	function updateDevis($db, $dvsiddvs, $dvsnbmgl, $dvsdtcre, $dvsidusr, $dvsdtexp, $cliidcli, $dvslblib, $dvstxdcl, $dvstxdpr, $dvsdtecl, $dvsdtlcl, $dvsdtefc, $dvsdtrfc) {
		$sql = "update deldvs set dvsnbmgl = ?, dvsdtcre = ?, dvsidusr = ?, dvsdtexp = ?, cliidcli = ?, dvslblib = ?, dvstxdcl = ?, dvstxdpr = ?, dvsdtecl = ?, dvsdtlcl = ?, dvsdtefc = ?, dvsdtrfc = ? where dvsiddvs = ?";
		$query = $db->query($sql, array($dvsnbmgl, $dvsdtcre, $dvsidusr, $dvsdtexp, $cliidcli, $dvslblib, $dvstxdcl, $dvstxdpr, $dvsdtecl, $dvsdtlcl, $dvsdtefc, $dvsdtrfc, $dvsiddvs));
	}
}


/**
 * Suppression d'un enregistrement
 */
if (!function_exists('deleteDevis')) {
	function deleteDevis($db, $dvsiddvs) {
		$sql = "delete from deldvs where dvsiddvs = ?";
		$query = $db->query($sql, array((int)$dvsiddvs));
	}
}


/**
 * Recupere les informations d'un enregistrement
 * @param object $db database object
 * @param int id de l'enregistrement
 * @return array
 */
if (!function_exists('getDevisRow')) {
	function getDevisRow($db, $dvsiddvs) {
		$sql = "select dvsiddvs, dvsnbmgl, dvsdtcre, dvsidusr, dvsdtexp, cliidcli, dvslblib, dvstxdcl, dvstxdpr, dvsdtecl, dvsdtlcl, dvsdtefc, dvsdtrfc from deldvs " .
		"where dvsiddvs = ?";
		$query = $db->query($sql, array($dvsiddvs));
		if ($query->num_rows() == 0) {
			return null;
		}
		return $query->row_array();
	}
}

?>
