<?php
/*
 * Created by generator
 *
 */

class Devis_model extends Model {
	
	var $dvsiddvs;
	var $dvsnbmgl;
	var $dvsdtcre;
	var $dvsidusr;
	var $dvsdtexp;
	var $cliidcli;
	var $dvslblib;
	var $dvstxdcl;
	var $dvstxdpr;
	var $dvsdtecl;
	var $dvsdtlcl;
	var $dvsdtefc;
	var $dvsdtrfc;
	
	/**
	 * Constructeur
	 */
	function Devis_model(){
		parent::Model();
		$this->load->helper('devis');
		
	}
	
	/************************************************************************
	 * Methodes de mise a jour a partir de la base de donnees
	 ************************************************************************/

	/**
	 * Cree une nouvelle instance a partir d'un enregistrement de base de donnees
	 */
	static function Devis_modelFromRow($row){
		$model = new Devis_model();
		$model->dvsiddvs = $row['dvsiddvs'];
		$model->dvsnbmgl = $row['dvsnbmgl'];
		$model->dvsdtcre = $row['dvsdtcre'];
		$model->dvsidusr = $row['dvsidusr'];
		$model->dvsdtexp = $row['dvsdtexp'];
		$model->cliidcli = $row['cliidcli'];
		$model->dvslblib = $row['dvslblib'];
		$model->dvstxdcl = $row['dvstxdcl'];
		$model->dvstxdpr = $row['dvstxdpr'];
		$model->dvsdtecl = $row['dvsdtecl'];
		$model->dvsdtlcl = $row['dvsdtlcl'];
		$model->dvsdtefc = $row['dvsdtefc'];
		$model->dvsdtrfc = $row['dvsdtrfc'];
		return $model;
	}

	/**
	 * recupere tous les enregistrements
	 * @param $db connexion a la base de donnees
	 */
	static function getAllDeviss($db){
		$rows = getAllDevissFromDB($db);
		$records = array();
		foreach ($rows as $row) {
			$records[] = Devis_model::Devis_modelFromRow($row);
		}
		return $records;
	}
	
	/**
	 * Recupere l'enregistrement a partir de son id
	 * @param $db database
	 * @param $dvsiddvs identifiant de l'enregistrement a recuperer
	 */
	static function getDevis($db, $dvsiddvs){
		$row = getDevisRow($db, $dvsiddvs);
		return Devis_model::Devis_modelFromRow($row);
	}
	
	/**
	 * Suppression d'un enregistrement
	 * @param $db database
	 * @param $dvsiddvs identifiant de l'enregistrement a supprimer
	 */
	static function delete($db, $dvsiddvs){
		deleteDevis($db, $dvsiddvs);
	}

	/**
	 * Enregistre en base un nouvel enregistrement
	 * @param $db
	 */
	public function save($db){
		$this->dvsiddvs = insertNewDevis($db, $this->dvsnbmgl, $this->dvsdtcre, $this->dvsidusr, $this->dvsdtexp, $this->cliidcli, $this->dvslblib, $this->dvstxdcl, $this->dvstxdpr, $this->dvsdtecl, $this->dvsdtlcl, $this->dvsdtefc, $this->dvsdtrfc);
	}

	/**
	 * Mise a jour des donnees d'un enregistrement
	 * @param db $db
	 */
	public function update($db){
		updateDevis($db, $this->dvsiddvs, $this->dvsnbmgl, $this->dvsdtcre, $this->dvsidusr, $this->dvsdtexp, $this->cliidcli, $this->dvslblib, $this->dvstxdcl, $this->dvstxdpr, $this->dvsdtecl, $this->dvsdtlcl, $this->dvsdtefc, $this->dvsdtrfc);
	}


}

?>
