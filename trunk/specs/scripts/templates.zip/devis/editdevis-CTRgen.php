<?php
/*
 * Created by generator
 *
 */

class EditDevis extends Controller {

	function EditDevis(){
		parent::Controller();
		$this->load->model('Devis_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}


	/**
	 * Affichage des infos
	 */
	public function index($dvsiddvs){
		$model = Devis_model::getDevis($this->db, $dvsiddvs);
		$data['devis'] = $model;

		$this->load->view('editdevis_view',$data);
	}

	/**
	 * Sauvegarde des modifications
	 */
	public function save(){
		// Mise a jour des donnees en base
		$model = new Devis_model();
		$model->dvsiddvs = $this->input->post('dvsiddvs');
		$model->dvsnbmgl = $this->input->post('margeGlobale'); 
		$model->dvsdtcre = $this->input->post('dateCreation'); 
		$model->dvsidusr = $this->input->post('auteur'); 
		$model->dvsdtexp = $this->input->post('dateExpiration'); 
		$model->cliidcli = $this->input->post('client'); 
		$model->dvslblib = $this->input->post('libelle'); 
		$model->dvstxdcl = $this->input->post('descriptionClient'); 
		$model->dvstxdpr = $this->input->post('descriptionPrivee'); 
		$model->dvsdtecl = $this->input->post('dateEngagementClient'); 
		$model->dvsdtlcl = $this->input->post('dateLivraisonClient'); 
		$model->dvsdtefc = $this->input->post('dateEnvoiFacture'); 
		$model->dvsdtrfc = $this->input->post('dateReceptionFacture'); 
		$model->update($this->db);

		$this->session->set_userdata('message', formatInfo('Devis mis a jour'));

		redirect('listdeviss/index'); 
	}
	
}
?>

