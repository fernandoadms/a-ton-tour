<?php
/*
 * Created by generator
 *
 */

$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('template');
?>

<html>
<head>
<? echo htmlHeader('Editer un Devis'); ?>

</head>
<body>

<div class="container">  
	<h1><img src="<?=base_url()?>www/images/logo.jpg"/ style="vertical-align:middle;"> Specs</h1>
	<hr>
	<div class="prepend-1 colborder">

<?= htmlNavigation() ?>
	<h2><img src="<?=base_url()?>www/images/devis.png"/ style="vertical-align:middle;"> Devis </h2>
	<div class="span-24">

	<fieldset>
<?
$attributes_info = array('name' => 'EditForm');
$fields_info = array('dvsiddvs' => $devis->dvsiddvs);
echo form_open_multipart('editdevis/save', $attributes_info, $fields_info );
?>
	<table>
		<tr><td><label for="margeGlobale">margeGlobale</label> : </td><td><input type="text" name="margeGlobale" id="margeGlobale" value="<?= $devis->dvsnbmgl ?>"></td></tr>
		<tr><td><label for="dateCreation">dateCreation</label> : </td><td><input type="text" name="dateCreation" id="dateCreation" value="<?= $devis->dvsdtcre ?>"></td></tr>
		<tr><td><label for="auteur">auteur</label> : </td><td><input type="text" name="auteur" id="auteur" value="<?= $devis->dvsidusr ?>"></td></tr>
		<tr><td><label for="dateExpiration">dateExpiration</label> : </td><td><input type="text" name="dateExpiration" id="dateExpiration" value="<?= $devis->dvsdtexp ?>"></td></tr>
		<tr><td><label for="client">client</label> : </td><td><input type="text" name="client" id="client" value="<?= $devis->cliidcli ?>"></td></tr>
		<tr><td><label for="libelle">libelle</label> : </td><td><input type="text" name="libelle" id="libelle" value="<?= $devis->dvslblib ?>"></td></tr>
		<tr><td><label for="descriptionClient">descriptionClient</label> : </td><td><input type="text" name="descriptionClient" id="descriptionClient" value="<?= $devis->dvstxdcl ?>"></td></tr>
		<tr><td><label for="descriptionPrivee">descriptionPrivee</label> : </td><td><input type="text" name="descriptionPrivee" id="descriptionPrivee" value="<?= $devis->dvstxdpr ?>"></td></tr>
		<tr><td><label for="dateEngagementClient">dateEngagementClient</label> : </td><td><input type="text" name="dateEngagementClient" id="dateEngagementClient" value="<?= $devis->dvsdtecl ?>"></td></tr>
		<tr><td><label for="dateLivraisonClient">dateLivraisonClient</label> : </td><td><input type="text" name="dateLivraisonClient" id="dateLivraisonClient" value="<?= $devis->dvsdtlcl ?>"></td></tr>
		<tr><td><label for="dateEnvoiFacture">dateEnvoiFacture</label> : </td><td><input type="text" name="dateEnvoiFacture" id="dateEnvoiFacture" value="<?= $devis->dvsdtefc ?>"></td></tr>
		<tr><td><label for="dateReceptionFacture">dateReceptionFacture</label> : </td><td><input type="text" name="dateReceptionFacture" id="dateReceptionFacture" value="<?= $devis->dvsdtrfc ?>"></td></tr>
		<tr>
			<td></td>
			<td>
				<button onclick="document.forms['EditForm'].sumbit()">
					<span class="ss_sprite ss_accept"> &nbsp; </span> Enregistrer
				</button>
			</td>
		</tr>
	</table>
<?
echo form_close('');
?>
	</fieldset>
	</div>
	</div>
</div>

</body>
</html>
