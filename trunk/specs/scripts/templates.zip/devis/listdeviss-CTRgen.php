<?php
/*
 * Created by generator
 *
 */

class ListDeviss extends Controller {

	/**
	 * Constructeur
	 */
	function ListDeviss(){
		parent::Controller();
		$this->load->model('Devis_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}

	/**
	 * Affichage des Devis
	 */
	public function index(){
		$data['deviss'] = Devis_model::getAllDeviss($this->db);
		$this->load->view('listdeviss_view', $data);
	}

	/**
	 * Ajout d'un Devis
	 */
	public function add(){

		// Insertion en base
		$model = new Devis_model();
		$model->dvsnbmgl = $this->input->post('margeGlobale'); 
		$model->dvsdtcre = $this->input->post('dateCreation'); 
		$model->dvsidusr = $this->input->post('auteur'); 
		$model->dvsdtexp = $this->input->post('dateExpiration'); 
		$model->cliidcli = $this->input->post('client'); 
		$model->dvslblib = $this->input->post('libelle'); 
		$model->dvstxdcl = $this->input->post('descriptionClient'); 
		$model->dvstxdpr = $this->input->post('descriptionPrivee'); 
		$model->dvsdtecl = $this->input->post('dateEngagementClient'); 
		$model->dvsdtlcl = $this->input->post('dateLivraisonClient'); 
		$model->dvsdtefc = $this->input->post('dateEnvoiFacture'); 
		$model->dvsdtrfc = $this->input->post('dateReceptionFacture'); 
		$model->save($this->db);

		$this->session->set_userdata('message', formatInfo('Nouveau Devis ajoute'));
		
		// Recharge la page avec les nouvelles infos
		redirect('listdeviss/index'); 
	}

	/**
	 * Suppression d'un Devis
	 * @param $dvsiddvs identifiant a supprimer
	 */
	function delete($dvsiddvs){
		Devis_model::delete($this->db, $dvsiddvs);

		$this->session->set_userdata('message', formatInfo('Devis supprime'));

		redirect('listdeviss/index'); 
	}

}
?>
