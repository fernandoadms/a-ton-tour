<?php
/*
 * Created by generator
 *
 */

$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('template');
?>

<html>
<head>
<? echo htmlHeader('Devis'); ?>

</head>
<body>


<div class="container">  
	<h1><img src="<?=base_url()?>www/images/logo.jpg"/ style="vertical-align:middle;"> Specs</h1>
	<hr>
	<div class="prepend-1 colborder">

<?= htmlNavigation() ?>


	<div class="span-12"><h2><img src="<?=base_url()?>www/images/devis.png"/ style="vertical-align:middle;"> Liste des Devis</h2></div>
	<div class="span-7 last" style="float: right;"><?echo $this->session->userdata('message'); $this->session->unset_userdata('message')?></div>

	<table class="visible">
		<tr class="header">
			<th>identifiant</th>
			<th>margeGlobale</th>
			<th>dateCreation</th>
			<th>auteur</th>
			<th>dateExpiration</th>
			<th>client</th>
			<th>libelle</th>
			<th>descriptionClient</th>
			<th>descriptionPrivee</th>
			<th>dateEngagementClient</th>
			<th>dateLivraisonClient</th>
			<th>dateEnvoiFacture</th>
			<th>dateReceptionFacture</th>
			<th>Supprimer</th>
		</tr>
	<?php
	$even = true;
	foreach($deviss as $devis):
	?>
		<tr <?=($even)?('class="even"'):('')?>>
			<td valign="top"><a title="Modifier ce Devis" href="<?=base_url()?>index.php/editdevis/index/<?=$devis->dvsiddvs?>"><?=$devis->dvsiddvs?></a></td>
			<td valign="top"><?=$devis->dvsnbmgl?></td> 
			<td valign="top"><?=$devis->dvsdtcre?></td> 
			<td valign="top"><?=$devis->dvsidusr?></td> 
			<td valign="top"><?=$devis->dvsdtexp?></td> 
			<td valign="top"><?=$devis->cliidcli?></td> 
			<td valign="top"><?=$devis->dvslblib?></td> 
			<td valign="top"><?=$devis->dvstxdcl?></td> 
			<td valign="top"><?=$devis->dvstxdpr?></td> 
			<td valign="top"><?=$devis->dvsdtecl?></td> 
			<td valign="top"><?=$devis->dvsdtlcl?></td> 
			<td valign="top"><?=$devis->dvsdtefc?></td> 
			<td valign="top"><?=$devis->dvsdtrfc?></td> 
			<td valign="top">
				<a href="#" title="Supprimer ce Devis" onclick="if(confirm('Desirez vous supprimer ce Devis ?')){location.href='<?=base_url()?>index.php/listdeviss/delete/<?=$devis->dvsiddvs?>'}">
				<img src="<?=base_url()?>www/images/delete_16.png"></a>
			</td>
		</tr>
		
	<?php $even = !$even;
	 endforeach;?>
</table>
<hr>
<fieldset>
	<legend><img src="<?=base_url()?>www/images/plus_16.png"> Ajouter un Devis</legend>

<?
$attributes_info = array('name' => 'AddForm');
$fields_info = array();
echo form_open_multipart('listdeviss/add', $attributes_info, $fields_info );
?>
	<table>
		<tr><td><label for="identifiant">identifiant</label> : </td><td><input type="text" name="identifiant" id="identifiant"></td></tr>
		<tr><td><label for="margeGlobale">margeGlobale</label> : </td><td><input type="text" name="margeGlobale" id="margeGlobale"></td></tr>
		<tr><td><label for="dateCreation">dateCreation</label> : </td><td><input type="text" name="dateCreation" id="dateCreation"></td></tr>
		<tr><td><label for="auteur">auteur</label> : </td><td><input type="text" name="auteur" id="auteur"></td></tr>
		<tr><td><label for="dateExpiration">dateExpiration</label> : </td><td><input type="text" name="dateExpiration" id="dateExpiration"></td></tr>
		<tr><td><label for="client">client</label> : </td><td><input type="text" name="client" id="client"></td></tr>
		<tr><td><label for="libelle">libelle</label> : </td><td><input type="text" name="libelle" id="libelle"></td></tr>
		<tr><td><label for="descriptionClient">descriptionClient</label> : </td><td><input type="text" name="descriptionClient" id="descriptionClient"></td></tr>
		<tr><td><label for="descriptionPrivee">descriptionPrivee</label> : </td><td><input type="text" name="descriptionPrivee" id="descriptionPrivee"></td></tr>
		<tr><td><label for="dateEngagementClient">dateEngagementClient</label> : </td><td><input type="text" name="dateEngagementClient" id="dateEngagementClient"></td></tr>
		<tr><td><label for="dateLivraisonClient">dateLivraisonClient</label> : </td><td><input type="text" name="dateLivraisonClient" id="dateLivraisonClient"></td></tr>
		<tr><td><label for="dateEnvoiFacture">dateEnvoiFacture</label> : </td><td><input type="text" name="dateEnvoiFacture" id="dateEnvoiFacture"></td></tr>
		<tr><td><label for="dateReceptionFacture">dateReceptionFacture</label> : </td><td><input type="text" name="dateReceptionFacture" id="dateReceptionFacture"></td></tr>
		<tr>
			<td></td>
			<td>
				<button onclick="document.forms['AddForm'].sumbit()">
					<span class="ss_sprite ss_add"> &nbsp; </span> Ajouter
				</button>
			</td>
		</tr>
	</table>

<?
echo form_close('');
?>
</fieldset>
	</div>
</div>

</body>
</html>
