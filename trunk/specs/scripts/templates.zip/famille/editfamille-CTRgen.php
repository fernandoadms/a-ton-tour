<?php
/*
 * Created by generator
 *
 */

class EditFamille extends Controller {

	function EditFamille(){
		parent::Controller();
		$this->load->model('Famille_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}


	/**
	 * Affichage des infos
	 */
	public function index($famidfam){
		$model = Famille_model::getFamille($this->db, $famidfam);
		$data['famille'] = $model;

		$this->load->view('editfamille_view',$data);
	}

	/**
	 * Sauvegarde des modifications
	 */
	public function save(){
		// Mise a jour des donnees en base
		$model = new Famille_model();
		$model->famidfam = $this->input->post('famidfam');
		$model->famidpar = $this->input->post('idParent'); 
		$model->famlblib = $this->input->post('libelle'); 
		$model->famlbuni = $this->input->post('unite'); 
		$model->update($this->db);

		$this->session->set_userdata('message', formatInfo('Famille mis a jour'));

		redirect('listfamilles/index'); 
	}
	
}
?>

