<?php
/*
 * Created by generator
 *
 */

$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('template');
?>

<html>
<head>
<? echo htmlHeader('Editer un Famille'); ?>

</head>
<body>

<div class="container">  
	<h1><img src="<?=base_url()?>www/images/logo.jpg"/ style="vertical-align:middle;"> Specs</h1>
	<hr>
	<div class="prepend-1 colborder">

<?= htmlNavigation() ?>
	<h2><img src="<?=base_url()?>www/images/famille.png"/ style="vertical-align:middle;"> Famille </h2>
	<div class="span-24">

	<fieldset>
<?
$attributes_info = array('name' => 'EditForm');
$fields_info = array('famidfam' => $famille->famidfam);
echo form_open_multipart('editfamille/save', $attributes_info, $fields_info );
?>
	<table>
		<tr><td><label for="idParent">idParent</label> : </td><td><input type="text" name="idParent" id="idParent" value="<?= $famille->famidpar ?>"></td></tr>
		<tr><td><label for="libelle">libelle</label> : </td><td><input type="text" name="libelle" id="libelle" value="<?= $famille->famlblib ?>"></td></tr>
		<tr><td><label for="unite">unite</label> : </td><td><input type="text" name="unite" id="unite" value="<?= $famille->famlbuni ?>"></td></tr>
		<tr>
			<td></td>
			<td>
				<button onclick="document.forms['EditForm'].sumbit()">
					<span class="ss_sprite ss_accept"> &nbsp; </span> Enregistrer
				</button>
			</td>
		</tr>
	</table>
<?
echo form_close('');
?>
	</fieldset>
	</div>
	</div>
</div>

</body>
</html>
