<?php
/*
 * Created by generator
 *
 */

class Famille_model extends Model {
	
	var $famidfam;
	var $famidpar;
	var $famlblib;
	var $famlbuni;
	
	/**
	 * Constructeur
	 */
	function Famille_model(){
		parent::Model();
		$this->load->helper('famille');
		
	}
	
	/************************************************************************
	 * Methodes de mise a jour a partir de la base de donnees
	 ************************************************************************/

	/**
	 * Cree une nouvelle instance a partir d'un enregistrement de base de donnees
	 */
	static function Famille_modelFromRow($row){
		$model = new Famille_model();
		$model->famidfam = $row['famidfam'];
		$model->famidpar = $row['famidpar'];
		$model->famlblib = $row['famlblib'];
		$model->famlbuni = $row['famlbuni'];
		return $model;
	}

	/**
	 * recupere tous les enregistrements
	 * @param $db connexion a la base de donnees
	 */
	static function getAllFamilles($db){
		$rows = getAllFamillesFromDB($db);
		$records = array();
		foreach ($rows as $row) {
			$records[] = Famille_model::Famille_modelFromRow($row);
		}
		return $records;
	}
	
	/**
	 * Recupere l'enregistrement a partir de son id
	 * @param $db database
	 * @param $famidfam identifiant de l'enregistrement a recuperer
	 */
	static function getFamille($db, $famidfam){
		$row = getFamilleRow($db, $famidfam);
		return Famille_model::Famille_modelFromRow($row);
	}
	
	/**
	 * Suppression d'un enregistrement
	 * @param $db database
	 * @param $famidfam identifiant de l'enregistrement a supprimer
	 */
	static function delete($db, $famidfam){
		deleteFamille($db, $famidfam);
	}

	/**
	 * Enregistre en base un nouvel enregistrement
	 * @param $db
	 */
	public function save($db){
		$this->famidfam = insertNewFamille($db, $this->famidpar, $this->famlblib, $this->famlbuni);
	}

	/**
	 * Mise a jour des donnees d'un enregistrement
	 * @param db $db
	 */
	public function update($db){
		updateFamille($db, $this->famidfam, $this->famidpar, $this->famlblib, $this->famlbuni);
	}


}

?>
