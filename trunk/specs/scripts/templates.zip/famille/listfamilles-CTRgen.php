<?php
/*
 * Created by generator
 *
 */

class ListFamilles extends Controller {

	/**
	 * Constructeur
	 */
	function ListFamilles(){
		parent::Controller();
		$this->load->model('Famille_model');
		$this->load->library('session');
		$this->load->helper('template');
		$this->load->helper('url');
	}

	/**
	 * Affichage des Famille
	 */
	public function index(){
		$data['familles'] = Famille_model::getAllFamilles($this->db);
		$this->load->view('listfamilles_view', $data);
	}

	/**
	 * Ajout d'un Famille
	 */
	public function add(){

		// Insertion en base
		$model = new Famille_model();
		$model->famidpar = $this->input->post('idParent'); 
		$model->famlblib = $this->input->post('libelle'); 
		$model->famlbuni = $this->input->post('unite'); 
		$model->save($this->db);

		$this->session->set_userdata('message', formatInfo('Nouveau Famille ajoute'));
		
		// Recharge la page avec les nouvelles infos
		redirect('listfamilles/index'); 
	}

	/**
	 * Suppression d'un Famille
	 * @param $famidfam identifiant a supprimer
	 */
	function delete($famidfam){
		Famille_model::delete($this->db, $famidfam);

		$this->session->set_userdata('message', formatInfo('Famille supprime'));

		redirect('listfamilles/index'); 
	}

}
?>
