<?php
/*
 * Created by generator
 *
 */

$this->load->helper('form');
$this->load->helper('url');
$this->load->helper('template');
?>

<html>
<head>
<? echo htmlHeader('Famille'); ?>

</head>
<body>


<div class="container">  
	<h1><img src="<?=base_url()?>www/images/logo.jpg"/ style="vertical-align:middle;"> Specs</h1>
	<hr>
	<div class="prepend-1 colborder">

<?= htmlNavigation() ?>


	<div class="span-12"><h2><img src="<?=base_url()?>www/images/famille.png"/ style="vertical-align:middle;"> Liste des Famille</h2></div>
	<div class="span-7 last" style="float: right;"><?echo $this->session->userdata('message'); $this->session->unset_userdata('message')?></div>

	<table class="visible">
		<tr class="header">
			<th>identifiant</th>
			<th>idParent</th>
			<th>libelle</th>
			<th>unite</th>
			<th>Supprimer</th>
		</tr>
	<?php
	$even = true;
	foreach($familles as $famille):
	?>
		<tr <?=($even)?('class="even"'):('')?>>
			<td valign="top"><a title="Modifier ce Famille" href="<?=base_url()?>index.php/editfamille/index/<?=$famille->famidfam?>"><?=$famille->famidfam?></a></td>
			<td valign="top"><?=$famille->famidpar?></td> 
			<td valign="top"><?=$famille->famlblib?></td> 
			<td valign="top"><?=$famille->famlbuni?></td> 
			<td valign="top">
				<a href="#" title="Supprimer ce Famille" onclick="if(confirm('Desirez vous supprimer ce Famille ?')){location.href='<?=base_url()?>index.php/listfamilles/delete/<?=$famille->famidfam?>'}">
				<img src="<?=base_url()?>www/images/delete_16.png"></a>
			</td>
		</tr>
		
	<?php $even = !$even;
	 endforeach;?>
</table>
<hr>
<fieldset>
	<legend><img src="<?=base_url()?>www/images/plus_16.png"> Ajouter un Famille</legend>

<?
$attributes_info = array('name' => 'AddForm');
$fields_info = array();
echo form_open_multipart('listfamilles/add', $attributes_info, $fields_info );
?>
	<table>
		<tr><td><label for="identifiant">identifiant</label> : </td><td><input type="text" name="identifiant" id="identifiant"></td></tr>
		<tr><td><label for="idParent">idParent</label> : </td><td><input type="text" name="idParent" id="idParent"></td></tr>
		<tr><td><label for="libelle">libelle</label> : </td><td><input type="text" name="libelle" id="libelle"></td></tr>
		<tr><td><label for="unite">unite</label> : </td><td><input type="text" name="unite" id="unite"></td></tr>
		<tr>
			<td></td>
			<td>
				<button onclick="document.forms['AddForm'].sumbit()">
					<span class="ss_sprite ss_add"> &nbsp; </span> Ajouter
				</button>
			</td>
		</tr>
	</table>

<?
echo form_close('');
?>
</fieldset>
	</div>
</div>

</body>
</html>
